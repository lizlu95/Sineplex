<?php
   define('DB_SERVER', 'localhost:3306');
   define('DB_USERNAME', 'pma');
   define('DB_PASSWORD', 'H8!{IMP]}T)l');
   define('DB_DATABASE', 'fhoyyzea_db');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>