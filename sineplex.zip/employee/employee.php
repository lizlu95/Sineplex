<!DOCTYPE HTML>
<html>  
<body>

<form action="welcome_employee.php" method="post">
E-mail: <input type="text" name="email"><br>
Password: <input type="password" name="password"><br>
<input type="submit">
</form>

</body>
</html>